﻿namespace CalculatorLib
{
    public class Calculator
    {
        /// <summary>
        /// Adds the specified x.
        /// </summary>
        /// <param name="x">The x.</param>
        /// <param name="y">The y.</param>
        /// <returns></returns>
        public static int Add(int x, int y)
        {
            return x + y;
        }
    }
}